##Privacy Statement - Hexbin Scatterplot  
  
The Hexbin Scatterplot custom visualization for Power BI does not collect personally identifiable information about you. It may be used to represent data in chart form exclusively for the Microsoft Power BI software. Any future version of this visual will also maintain this same behavior. The Hexbin Scatterplot cannot control what data you choose to represent in Power BI nor how you choose to distribute in print or digital form.   
  
As an optional add-on to the Power BI software by Microsoft, the Hexbin Scatterplot visual may be redistributed as part of a third party solution. Personal or commercial use as well as the use in any third party solution is outside of the control of the Hexbin Scatterplot developer. You should read the privacy and terms of service of any third party service or solution before using it.
