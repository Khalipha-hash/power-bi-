Open the following link, then copy and paste the template code into DevTools. This code is the *YourVisual* starter code with the sample table removed. You will gradually add code to this template to build your visual.

https://gist.githubusercontent.com/deldersveld/dbfc69576c0c80bc80cd67ea1593fe10/raw/cd966f988f8c7bbdd1cdd07afd3982737629ad30/PowerBITemplate.ts

```
asdfds
```
