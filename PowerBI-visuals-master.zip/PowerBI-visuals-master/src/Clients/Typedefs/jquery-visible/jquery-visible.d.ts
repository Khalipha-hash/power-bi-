interface JQuery {
    visible(): boolean;
}