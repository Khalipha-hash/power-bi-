# PowerBIRestDemo
Power BI Preview Rest Demo Code
