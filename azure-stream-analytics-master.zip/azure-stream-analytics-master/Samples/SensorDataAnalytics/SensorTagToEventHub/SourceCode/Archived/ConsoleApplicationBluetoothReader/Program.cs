﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Diagnostics;
using System.Threading;
using X2CodingLab.SensorTag;
using X2CodingLab.SensorTag.Exceptions;
using X2CodingLab.SensorTag.Sensors;
//using Windows.Devices.Enumeration;
using ClassLibrary1;


namespace ConsoleApplicationBluetoothReader
{
    class Program
    {

        static void Main(string[] args)
        {

            Class1 cs = new Class1();
            //string temp = cs.tagstext();
            //Console.WriteLine( temp);
            Console.ReadLine();
        }


    }
}
