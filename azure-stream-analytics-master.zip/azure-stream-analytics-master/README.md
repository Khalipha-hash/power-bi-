# Microsoft Azure Stream Analytics #

For more information about the Stream Analytics service, see [http://azure.microsoft.com/en-us/services/stream-analytics/](http://azure.microsoft.com/en-us/services/stream-analytics/)

