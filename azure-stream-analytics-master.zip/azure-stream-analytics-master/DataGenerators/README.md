# Microsoft Azure Stream Analytics #

This folder contains event generators for Azure Stream Analytics.
 
For tutorials that reference these samples, see [http://azure.microsoft.com/en-us/documentation/services/stream-analytics/](http://azure.microsoft.com/en-us/documentation/services/stream-analytics/)

For more information about the Stream Analytics service, please see [http://azure.microsoft.com/en-us/services/stream-analytics/](http://azure.microsoft.com/en-us/services/stream-analytics/)

