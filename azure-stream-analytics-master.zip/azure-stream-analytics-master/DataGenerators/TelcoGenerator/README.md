# TelcoGenerator #

This folder contains a solution that generates Telecommunication events and pushes them to an Event Hub instance.  For instructions on using this generator, see [http://azure.microsoft.com/en-us/documentation/articles/stream-analytics-get-started/](http://azure.microsoft.com/en-us/documentation/articles/stream-analytics-get-started/) 

