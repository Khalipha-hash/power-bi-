These files can be used to test Stream Analytics queries locally and using the Test Feature in the Azure Portal. To run a query against sample data, click the "Test" button on the Query page, and upload the sample data file that you wish to use. 

