# queue-trigger-rssfeed-crawler
Azure Functions Queue Trigger Python Sample that get RSS feed URL from Queue and dump all items that obtained from RSS feed


## Add RSS feeds to Queue to trigger the function
```
https://azure.microsoft.com/en-us/blog/feed/
https://azure.microsoft.com/en-us/updates/feed/
...
```
