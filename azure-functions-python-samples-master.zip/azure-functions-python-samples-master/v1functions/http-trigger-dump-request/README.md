# http-trigger-dump-request
Azure Functions HTTP Trigger Python Sample that get and dump HTTPS request info that the trigger receives


| Trigger | In/Out Bindings |
------------ | ----------- |
| HTTP Trigger | output:HTTP |


Support both Python 2 and 3.X

