# timer-trigger-azuresearch-index-monitoring
Azure Functions Timer Trigger Python Sample that get Azure Search index statistics via API and store the results into DocumentDB
